import addOnUISdk from "https://new.express.adobe.com/static/add-on-sdk/sdk.js";

addOnUISdk.ready.then(async () => {
    console.log("addOnUISdk is ready for use.");

    // Get the UI runtime.
    const { runtime } = addOnUISdk.instance;

    // Get the proxy object, which is required
    // to call the APIs defined in the Document Sandbox runtime
    // i.e., in the `code.js` file of this add-on.
    const sandboxProxy = await runtime.apiProxy("documentSandbox");

    // Set up animation for button click
    const animateButtonClick = (button) => {
        button.style.transform = 'scale(0.95)';
        setTimeout(() => {
            button.style.transform = '';
        }, 150);
    };

    // Blue rectangle button
    const createRectangleButton = document.getElementById("createRectangle");
    createRectangleButton.addEventListener("click", async event => {
        animateButtonClick(event.currentTarget);
        await sandboxProxy.createRectangle();
    });

    // Green rectangle button
    const createGreenRectangleButton = document.getElementById("createGreenRectangle");
    createGreenRectangleButton.addEventListener("click", async event => {
        animateButtonClick(event.currentTarget);
        await sandboxProxy.createGreenRectangle();
    });

    // Enable the buttons only when:
    // 1. `addOnUISdk` is ready,
    // 2. `sandboxProxy` is available, and
    // 3. `click` event listeners are registered.
    createRectangleButton.disabled = false;
    createGreenRectangleButton.disabled = false;
});
